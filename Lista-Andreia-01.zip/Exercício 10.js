//Exercício 10

let ultimoItem = listaDeCompras[listaDeCompras.length - 1];
console.log(ultimoItem);