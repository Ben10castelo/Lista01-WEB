//Exercício 3

let isEstudante = true;
console.log(isEstudante);