//Exercício 11

let idadeString = "25";
let idadeNumero = Number(idadeString);
console.log(idadeNumero);