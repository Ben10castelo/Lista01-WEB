//Exercicio 1

let idade = 25;
console.log(idade);