//Exercício 5

let frase = "Olá, mundo!";
console.log(frase);