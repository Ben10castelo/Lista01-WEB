//Exercício 6

let tamanhoFrase = frase.length;
console.log(tamanhoFrase);