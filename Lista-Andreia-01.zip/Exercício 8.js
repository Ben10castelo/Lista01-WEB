//Exercício 8

let listaDeCompras = ["pão", "leite", "ovos"];
console.log(listaDeCompras);