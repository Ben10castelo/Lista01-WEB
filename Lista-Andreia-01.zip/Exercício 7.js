//Exercício 7

let temNumero = frase.includes("1");
console.log(temNumero);