//Exercício 2

let nome = "Ben10";
console.log(nome);