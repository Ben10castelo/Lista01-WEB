//Exercício 12

let precoProduto = 12.5;
let precoArredondado = Math.round(precoProduto);
console.log(precoArredondado)