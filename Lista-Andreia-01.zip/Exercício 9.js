// exercício 9

let primeiroItem = listaDeCompras[0];
console.log(primeiroItem);